package lucene;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DisplayXML {
	
    public List<String> getRequetes(String filePath) {
        List<String> requetes = new ArrayList<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            StringBuilder xmlContent = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                xmlContent.append(line.trim());
            }

            reader.close();

            String xmlString = xmlContent.toString();

            int topicStartIndex = xmlString.indexOf("<top>");
            int topicEndIndex = xmlString.indexOf("</top>");

            while (topicStartIndex != -1 && topicEndIndex != -1) {
                String topicString = xmlString.substring(topicStartIndex, topicEndIndex + 6);
                String requete = processTopic(topicString);
                requetes.add(requete);
                xmlString = xmlString.substring(topicEndIndex + 6);
                topicStartIndex = xmlString.indexOf("<top>");
                topicEndIndex = xmlString.indexOf("</top>");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return requetes;
    }

    private String processTopic(String topicString) {
        String title = getValueByTagName(topicString, "title");
        String desc = getValueByTagName(topicString, "desc");
        
        return title + ". " + desc;
    }

    private String getValueByTagName(String topicString, String tagName) {
        int startIndex = topicString.indexOf("<" + tagName + ">") + tagName.length() + 2;
        int endIndex = topicString.indexOf("</" + tagName + ">");
        return topicString.substring(startIndex, endIndex);
    }
}
