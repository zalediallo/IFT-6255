package lucene;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.file.Paths;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TotalHits;
import org.apache.lucene.search.similarities.BM25Similarity;
import org.apache.lucene.store.FSDirectory;
import java.util.List;

public class BM25Search {
    public static void main(String[] args) throws Exception {
        String indexPath = "C:\\Users\\lilsa\\Downloads\\Data\\indexWithSW";
        
        String requetesfile = "C:\\Users\\lilsa\\Downloads\\Data\\requetes.xml"; // Le fichier contenant les 50 requetes
        DisplayXML displayXML = new DisplayXML();
        List<String> queries = displayXML.getRequetes(requetesfile);

        IndexReader reader = DirectoryReader.open(FSDirectory.open(Paths.get(indexPath)));
        IndexSearcher searcher = new IndexSearcher(reader);
        
        // Définir les paramètres k1 et b pour le modèle BM25
        // Définir les paramètres k1 et b pour le modèle BM25
        /**
         * Ce paramètre contrôle la saturation de la fréquence des termes dans le document. 
         * Une valeur plus élevée de k1 augmente l'importance de la fréquence du terme dans 
         * le calcul du score de pertinence. Une valeur typique recommandée pour est 1.2, 
         * mais cela peut varier en fonction du corpus et des besoins spécifiques.
         */
        float k1 = 1.2f; // valeur par défaut recommandée pour k1
        /**
         * Ce paramètre contrôle l'effet de la longueur du document sur le score de pertinence. 
         * Une valeur plus élevée de b donne plus de poids aux documents plus courts, 
         * tandis qu'une valeur plus faible donne plus de poids aux documents plus longs. 
         * Une valeur typique recommandée pour b est 0.75, mais encore une fois, 
         * cela peut varier en fonction du corpus et des besoins spécifiques.
         */
        float b = 0.75f; // valeur par défaut recommandée pour b
        searcher.setSimilarity(new BM25Similarity(k1, b));

        StandardAnalyzer analyzer = new StandardAnalyzer();
        
        String outputFile = "C:\\Users\\lilsa\\Downloads\\Data\\R_BM25_YES_SW.txt"; // Nom du fichier de sortie
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile, true));
        
        int j = 1; //pour id de la requete
        for (int k = 0; k < queries.size(); k++) {
            String queryId = queries.get(k).toString();
            System.out.println("Query: " + k + " " + queryId);
            
            QueryParser parser = new QueryParser("contents", analyzer);
            Query query = parser.parse(queryId);

            int hitsPerPage = 1000;
            TopDocs results = searcher.search(query, hitsPerPage);
            ScoreDoc[] hits = results.scoreDocs;
            
            TotalHits totalHits = results.totalHits;
            int numTotalHits = Math.toIntExact(totalHits.value);

            for (int i = 0; i < hits.length; i++) {
                ScoreDoc hit = hits[i];
                Document doc = searcher.doc(hit.doc);
                String path = doc.get("path");
                String[] pathSegments = path.split("\\\\");
                String fileName = pathSegments[pathSegments.length - 1];
                // query_id  Q0  document_id  rank  score  run_id
                writer.write((k + 1) + " Q0 " + fileName + " " + (i+1) + " " + hit.score + " BM25");
                writer.newLine();
            }
            
            //j++;
        }
        writer.close(); // Fermer le BufferedWriter

        reader.close();
    }
}
