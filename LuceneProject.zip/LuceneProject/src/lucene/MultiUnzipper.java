package lucene;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;

public class MultiUnzipper {
    public static void main(String[] args) {
        String zipDirectoryPath = "C:\\Users\\lilsa\\Downloads\\Data\\AP";
        String destDir = "C:\\Users\\lilsa\\Downloads\\Data\\Unzipped";

        unzipAll(zipDirectoryPath, destDir);
    }

    public static void unzipAll(String zipDirectoryPath, String destDir) {
        File dir = new File(destDir);
        // crée le répertoire de destination s'il n'existe pas
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File zipDirectory = new File(zipDirectoryPath);
        File[] files = zipDirectory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.getName().toLowerCase().endsWith(".gz")) { // Vérifie si le fichier est un fichier .gz
                    unzip(file.getAbsolutePath(), destDir);
                }
            }
        } else {
            System.out.println("Aucun fichier trouvé dans le répertoire spécifié.");
        }
    }

    public static void unzip(String zipFilePath, String destDir) {
        byte[] buffer = new byte[1024];
        try {
            FileInputStream fis = new FileInputStream(zipFilePath);
            GZIPInputStream gzis = new GZIPInputStream(fis);
            String fileName = new File(zipFilePath).getName(); // Obtient le nom du fichier
            File newFile = new File(destDir + File.separator + fileName.substring(0, fileName.length() - 3)); // Supprime l'extension .gz du nom de fichier
            FileOutputStream fos = new FileOutputStream(newFile);
            int len;
            while ((len = gzis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            gzis.close();
            System.out.println("Extraction terminée pour : " + zipFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
