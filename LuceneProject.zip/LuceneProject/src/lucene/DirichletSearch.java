package lucene;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TotalHits;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.search.similarities.LMDirichletSimilarity; // Importer la classe LMDirichletSimilarity

public class DirichletSearch {
    public static void main(String[] args) throws IOException, ParseException {
        String indexPath = "C:\\Users\\lilsa\\Downloads\\Data\\indexWithSW";
        //String queryString = "Computer";
        /**String[] queries = {
                "machine",
                "saliou",
                "usa"
        };**/
        
        String requetesfile = "C:\\Users\\lilsa\\Downloads\\Data\\requetes.xml"; // Le fichier contenant les 50 requetes
        DisplayXML displayXML = new DisplayXML();
        List<String> queries = displayXML.getRequetes(requetesfile);

        IndexReader reader = DirectoryReader.open(FSDirectory.open(Paths.get(indexPath)));
        IndexSearcher searcher = new IndexSearcher(reader);
        
        // Définir la similarité de lissage Dirichlet pour le chercheur avec le paramètre mu
        searcher.setSimilarity(new LMDirichletSimilarity(1000.0f)); // Paramètre mu = 1000.0 compris entre 500 et 2000

        StandardAnalyzer analyzer = new StandardAnalyzer();
        
    	String outputFile = "C:\\Users\\lilsa\\Downloads\\Data\\R_DIRICHLET_YES_SW.txt"; // Nom du fichier de sortie
    	BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile, true));

    	int j = 1; //pour id de la requete
    	for (int k = 0; k < queries.size(); k++) {
        	String queryId = queries.get(k).toString();
        	System.out.println("Query: " +k+ " "+queryId);
    		
        	QueryParser parser = new QueryParser("contents", analyzer);
        	Query query = parser.parse(queryId);

        	int hitsPerPage = 1000;
        	TopDocs results = searcher.search(query, hitsPerPage);
        	ScoreDoc[] hits = results.scoreDocs;
        
        	TotalHits totalHits = results.totalHits;
        	int numTotalHits = Math.toIntExact(totalHits.value);

        	for (int i = 0; i < hits.length; i++) {
        		ScoreDoc hit = hits[i];
        		Document doc = searcher.doc(hit.doc);
        		String path = doc.get("path");
        		String[] pathSegments = path.split("\\\\");
        		String fileName = pathSegments[pathSegments.length - 1];
        		// query_id  Q0  document_id  rank  score  run_id
        		writer.write((k + 1) + " Q0 " + fileName + " " + (i+1) + " " + hit.score + " Dirichlet");
        		writer.newLine();
        	}
        }

        reader.close();
    }
}
