package lucene;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class XMLParseur {
    public static void main(String[] args) {
        // Chemin vers le fichier à lire
        String cheminFichier = "C:\\Users\\lilsa\\Downloads\\Data\\topics.1-50.txt";
        // Chemin vers le fichier de sortie
        String cheminFichierSortie = "C:\\Users\\lilsa\\Downloads\\Data\\requetes.xml";

        try {
            // Création d'un objet BufferedReader pour lire le fichier
            BufferedReader lecteur = new BufferedReader(new FileReader(cheminFichier));
            // Création d'un objet PrintWriter pour écrire dans le fichier de sortie
            PrintWriter writer = new PrintWriter(cheminFichierSortie);

            // Écriture de l'en-tête XML
            writer.println("<topics>");

            String ligne;

            int i = 0;
            // Lire et afficher chaque ligne jusqu'à la fin du fichier
            while ((ligne = lecteur.readLine()) != null) {
                // Vérifier si la ligne contient le tag <title> ou <desc>
                if (ligne.contains("<title>")) {
                    // Supprimer "Topic:", "<title>" 
                    ligne = ligne.replace("Topic: ", "").trim().replace("<title> ", "").trim();
                    i++;
                    // Écrire dans le fichier de sortie
                    writer.println("\t<top>");
                    writer.println("\t\t<num>" + i + "</num>");
                    writer.println("\t\t<title>" + ligne + "</title>");
                }
                if (ligne.contains("<desc>")) {
                    ligne = ligne.replace("Description:", "").trim().replace("<desc>  ", "").trim();
                    // Écrire dans le fichier de sortie
                    writer.println("\t\t<desc>" + ligne + "</desc>");
                    writer.println("\t</top>");
                }
            }

            // Écriture de la balise de fermeture
            writer.println("</topics>");

            // Fermer le lecteur
            lecteur.close();
            // Fermer le writer
            writer.close();
        } catch (IOException e) {
            // Gérer les erreurs d'entrée/sortie (IOException)
            e.printStackTrace();
        }
    }
}

