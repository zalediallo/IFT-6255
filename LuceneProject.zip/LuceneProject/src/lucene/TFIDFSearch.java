package lucene;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.file.Paths;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TotalHits;
import org.apache.lucene.store.FSDirectory;
import java.util.List;

public class TFIDFSearch {
    public static void main(String[] args) throws Exception {
        String indexPath = "C:\\Users\\lilsa\\Downloads\\Data\\indexWithSW";
        
        String requetesfile = "C:\\Users\\lilsa\\Downloads\\Data\\requetes.xml"; // Le fichier contenant les 50 requetes
        DisplayXML displayXML = new DisplayXML();
        List<String> queries = displayXML.getRequetes(requetesfile);

        IndexReader reader = DirectoryReader.open(FSDirectory.open(Paths.get(indexPath)));
        IndexSearcher searcher = new IndexSearcher(reader);
        StandardAnalyzer analyzer = new StandardAnalyzer();
        
    	String outputFile = "C:\\Users\\lilsa\\Downloads\\Data\\R_TFIDF_YES_SW.txt"; // Nom du fichier de sortie
    	BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile, true));
        
        int j = 1; //pour id de la requete
        for (int k = 0; k < queries.size(); k++) {
        	String queryId = queries.get(k).toString();
        	System.out.println("Query: " +k+ " "+queryId);
        	
        	QueryParser parser = new QueryParser("contents", analyzer);
        	Query query = parser.parse(queryId);

        	int hitsPerPage = 1000;
        	TopDocs results = searcher.search(query, hitsPerPage);
        	ScoreDoc[] hits = results.scoreDocs;
        
        	TotalHits totalHits = results.totalHits;
        	int numTotalHits = Math.toIntExact(totalHits.value);

        	for (int i = 0; i < hits.length; i++) {
        		ScoreDoc hit = hits[i];
        		Document doc = searcher.doc(hit.doc);
        		String path = doc.get("path");
        		String[] pathSegments = path.split("\\\\");
        		String fileName = pathSegments[pathSegments.length - 1];
        		// query_id  Q0  document_id  rank  score  run_id
        		writer.write((k + 1) + " Q0 " + fileName + " " + (i+1) + " " + hit.score + " TF_IDF");
        		writer.newLine();
        	}
        	
        	//j++;
        }
        writer.close(); // Fermer le BufferedWriter

        reader.close();
    }
}
