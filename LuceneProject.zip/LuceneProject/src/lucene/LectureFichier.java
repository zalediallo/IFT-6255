package lucene;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LectureFichier {
    public static void main(String[] args) {
        // Chemin vers le fichier à lire
        String cheminFichier = "C:\\Users\\lilsa\\Downloads\\Data\\topics.1-50.txt";

        try {
            // Création d'un objet BufferedReader pour lire le fichier
            BufferedReader lecteur = new BufferedReader(new FileReader(cheminFichier));

            String ligne;
            
            int i = 0;
            // Lire et afficher chaque ligne jusqu'à la fin du fichier
            while ((ligne = lecteur.readLine()) != null) {
                // Vérifier si la ligne contient le tag <title> ou <desc>
                if (ligne.contains("<title>")) {
                    // Supprimer "Topic:", "<title>" 
                    //ligne = ligne.replace("Topic:", "").replace("<title>  ", "requete " + (i + 1) + ":");
                	ligne = ligne.replace("Topic: ", "");
                    i++;
                    System.out.println(ligne);
                }
                if (ligne.contains("<desc>")) {
                	ligne = ligne.replace("Description:", "");
                	System.out.println(ligne);
                }
            }

            // Fermer le lecteur
            lecteur.close();
        } catch (IOException e) {
            // Gérer les erreurs d'entrée/sortie (IOException)
            e.printStackTrace();
        }
    }
}
