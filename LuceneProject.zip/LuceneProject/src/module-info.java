/**
 *
 */
/**
 *
 */
module LuceneProject {
	requires lucene.core;
	requires lucene.queryparser;
	//requires org.apache.lucene.analysis.common;
	//requires lucene.core;
}